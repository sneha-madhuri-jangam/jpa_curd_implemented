package com.example.demo.controller;
//package com.example.demo.student;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Student;
import com.example.demo.StudentRepository;

@RestController
public class StudentController {
	
	@Autowired
	StudentRepository repo;
	
	//get all student details
	@GetMapping("/students")
	public List<Student> getAllStudents(){
		 
		
		List<Student> students=repo.findAll();
		return students;		
		
	}
	
	//get students by id
	@GetMapping("/studentsbyid/{id}")
	public Student getAllStudentsbyid(@PathVariable int id){
		 
		
		Student student=repo.findById(id).get();
		return student;
			
	}
	
	
	
	//post data to table
	@PostMapping("/students/add")
	public void createStudent1(@RequestBody Student stu) {
		
		repo.save(stu);
		
	}
	
		
	
	//update data to table by id
		@PutMapping("/updating/{id}")
		public Student updatestudent(@PathVariable int id) {
			
			 Student modify_stu=repo.findById(id).get();
			 modify_stu.setName("madhuri");
			 modify_stu.setBranch("civil");		 
			 
			 repo.save(modify_stu);
			return modify_stu;
								
		}
	
	
	// delete the data by id
	@DeleteMapping("/deletebyid/{id}")
	public void deleteby_id(@PathVariable int id) {
		//repo.deleteById(id);--> works fine no worries
		Student byestudent=repo.findById(id).get(); // once to got details of that object u pass it to the object of particular student
		repo.delete(byestudent);
			
	}
	

}
